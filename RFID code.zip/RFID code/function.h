#ifndef _function
#define _function

bool compareUids(byte* uid1, byte* uid2);
void pushToFirebase(byte* uid);

void READ_SETUP() {

  SPI.begin();      // Init SPI bus
  rfid.PCD_Init();  // Init MFRC522
  Serial.println(F("Scan a PICC to see UID, SAK, and type..."));
}

void READ_LOOP() {

  if (!rfid.PICC_IsNewCardPresent()) return;
  if (!rfid.PICC_ReadCardSerial()) return;

  Serial.print(F("PICC UID: "));
  for (byte i = 0; i < rfid.uid.size; i++) {
    Serial.print(rfid.uid.uidByte[i], HEX);
    Serial.print(" ");
  }
  Serial.println();

  rfid.PICC_HaltA();
  rfid.PCD_StopCrypto1();
}

void addUid(byte* uid) {
  UIDNode* newNode = new UIDNode();
  memcpy(newNode->uid, uid, 4);
  newNode->next = uidList;
  uidList = newNode;
}

bool checkAndRemoveUid(byte* uid) {
  UIDNode* current = uidList;
  UIDNode* previous = nullptr;

  while (current != nullptr) {
    if (compareUids(current->uid, uid)) {
      // Remove node
      if (previous) {
        previous->next = current->next;
      } else {
        uidList = current->next;  // Move head
      }
      delete current;  // Free memory
      return true;     // UID was found and removed
    }
    previous = current;
    current = current->next;
  }
  return false;  // UID was not found
}

bool compareUids(byte* uid1, byte* uid2) {
  return memcmp(uid1, uid2, 4) == 0;
}

void printHex(byte* buffer, byte bufferSize) {
  for (byte i = 0; i < bufferSize; i++) {
    Serial.print(buffer[i] < 0x10 ? " 0" : " ");
    Serial.print(buffer[i], HEX);
  }
  Serial.println();
}

void ADD_DELET_DATA() {

  if (!rfid.PICC_IsNewCardPresent() || !rfid.PICC_ReadCardSerial()) {
    return;
  }

  if (checkAndRemoveUid(rfid.uid.uidByte)) {
    Serial.print(F("UID already present, removed: "));
    printHex(rfid.uid.uidByte, 4);
  } else {
    addUid(rfid.uid.uidByte);
    Serial.print(F("Added new UID: "));
    printHex(rfid.uid.uidByte, 4);
    pushToFirebase(rfid.uid.uidByte);
  }
  delay(2000);
}

void wifi_setup() {
  // Connect to Wi-Fi
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("Connected to Wi-Fi");

  // Set Firebase host and authentication token in config
  firebaseConfig.host = FIREBASE_HOST;
  firebaseConfig.signer.tokens.legacy_token = FIREBASE_AUTH;

  // Initialize Firebase with config and authentication
  Firebase.begin(&firebaseConfig, &firebaseAuth);
  Firebase.reconnectWiFi(true);  // Automatically reconnect to Wi-Fi if disconnected

  // Check if Firebase is ready for operations
  if (Firebase.ready()) {
    Serial.println("Firebase ready for operations.");
  } else {
    Serial.println("Firebase initialization failed.");
    Serial.println(firebaseData.errorReason());  // Display error if initialization fails
  }
}




/****FIREBASE FUNCTION****/

void pushToFirebase(byte* uid) {
  String path = "/UIDs";  // Firebase database path
  String uidStr = "";

  // Convert UID bytes to string
  for (byte i = 0; i < 4; i++) {
    uidStr += String(uid[i], HEX);
    if (i < 3) uidStr += ":";
  }

  // Push to Firebase
  if (Firebase.pushString(firebaseData, path, uidStr)) {
    Serial.println("Data pushed to Firebase.");
  } else {
    Serial.println("Failed to push data to Firebase.");
    Serial.println(firebaseData.errorReason());
  }
}


#endif
#ifndef _var
#define _var

/*WIRING AS PER OUR CIRCUIT*/
#define SS_PIN D1 
#define RST_PIN D2

MFRC522 rfid(SS_PIN, RST_PIN); // Instance of the class
MFRC522::MIFARE_Key key; 

byte nuidPICC[4]; // Head of the linked list

struct UIDNode {
  byte uid[4];
  UIDNode* next;
};

UIDNode* uidList = nullptr;

/**FIRE BASE API VARIABLES **/
FirebaseConfig firebaseConfig;
FirebaseAuth firebaseAuth;
FirebaseData firebaseData;

#define FIREBASE_HOST "https://industrial-rfid-project-default-rtdb.firebaseio.com/"  // Replace with your Firebase database URL
#define FIREBASE_AUTH "eSkQSZPgi5OspcSIGpqdRprvJyljYnDlqFvC72z0" 


/**WIFI **/

const char* ssid = "ITS_AKK";
const char* password = "22222228"; 

#endif